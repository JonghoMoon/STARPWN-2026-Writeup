/************************************************************************
 * NASA Docket No. GSC-19,200-1, and identified as "cFS Draco"
 *
 * Copyright (c) 2023 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

/* PSP coverage stub replacement for sys/stat.h */
#ifndef PCS_SYS_STAT_H
#define PCS_SYS_STAT_H

#include "PCS_basetypes.h"
#include "PCS_fcntl.h"

/* ----------------------------------------- */
/* constants normally defined in sys/stat.h */
/* ----------------------------------------- */

/* ----------------------------------------- */
/* types normally defined in sys/stat.h */
/* ----------------------------------------- */
struct PCS_stat
{
    int value;
};

struct PCS_statfs
{
    long    f_bsize;
    int64_t f_bavail;
};

/* ----------------------------------------- */
/* prototypes normally declared in sys/stat.h */
/* ----------------------------------------- */
extern int PCS_stat(const char *path, struct PCS_stat *buf);
extern int PCS_statfs(const char *path, struct PCS_statfs *buf);

#endif
