/************************************************************************
 * NASA Docket No. GSC-19,200-1, and identified as "cFS Draco"
 *
 * Copyright (c) 2023 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

/* PSP coverage stub replacement for rtems_bsdnet.h */
#ifndef OVERRIDE_BSDNET_H
#define OVERRIDE_BSDNET_H

#include "PCS_bsdnet.h"

#define rtems_status_text               PCS_rtems_status_text
#define rtems_bsdnet_do_dhcp_failsafe   PCS_rtems_bsdnet_do_dhcp_failsafe
#define rtems_bsdnet_initialize_network PCS_rtems_bsdnet_initialize_network
#define rtems_fxp_attach                PCS_rtems_fxp_attach

#endif
