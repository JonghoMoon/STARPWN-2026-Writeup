/************************************************************************
 * NASA Docket No. GSC-19,200-1, and identified as "cFS Draco"
 *
 * Copyright (c) 2023 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

/**
 * @file
 *
 * Auto-Generated stub implementations for functions defined in PCS_threadimpl header
 */

#include "PCS_threadimpl.h"
#include "utgenstub.h"

/*
 * ----------------------------------------------------
 * Generated stub function for PCS_Thread_Get_CPU_time_used_after_last_reset()
 * ----------------------------------------------------
 */
PCS_Timestamp_Control PCS_Thread_Get_CPU_time_used_after_last_reset(PCS_Thread_Control *the_thread)
{
    UT_GenStub_SetupReturnBuffer(PCS_Thread_Get_CPU_time_used_after_last_reset, PCS_Timestamp_Control);

    UT_GenStub_AddParam(PCS_Thread_Get_CPU_time_used_after_last_reset, PCS_Thread_Control *, the_thread);

    UT_GenStub_Execute(PCS_Thread_Get_CPU_time_used_after_last_reset, Basic, NULL);

    return UT_GenStub_GetReturnValue(PCS_Thread_Get_CPU_time_used_after_last_reset, PCS_Timestamp_Control);
}

/*
 * ----------------------------------------------------
 * Generated stub function for PCS_Thread_Get_name()
 * ----------------------------------------------------
 */
size_t PCS_Thread_Get_name(const PCS_Thread_Control *the_thread, char *buffer, size_t buffer_size)
{
    UT_GenStub_SetupReturnBuffer(PCS_Thread_Get_name, size_t);

    UT_GenStub_AddParam(PCS_Thread_Get_name, const PCS_Thread_Control *, the_thread);
    UT_GenStub_AddParam(PCS_Thread_Get_name, char *, buffer);
    UT_GenStub_AddParam(PCS_Thread_Get_name, size_t, buffer_size);

    UT_GenStub_Execute(PCS_Thread_Get_name, Basic, NULL);

    return UT_GenStub_GetReturnValue(PCS_Thread_Get_name, size_t);
}
