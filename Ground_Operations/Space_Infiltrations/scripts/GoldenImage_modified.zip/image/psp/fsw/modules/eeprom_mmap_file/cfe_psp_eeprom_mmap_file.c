/************************************************************************
 * NASA Docket No. GSC-19,200-1, and identified as "cFS Draco"
 *
 * Copyright (c) 2023 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

/**
 * \file
 *
 *  Created on: Jul 17, 2015
 *      Author: joseph.p.hickey@nasa.gov
 *
 * This is an implementation of the PSP EEPROM API calls that operates on a
 * memory-mapped disk file, therefore emulating the persistence of a real eeprom device.
 */

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/stat.h>

#include "cfe_psp.h"
#include "cfe_psp_module.h"

/*
** Defines
*/
#define EEPROM_FILE "EEPROM.DAT"

CFE_PSP_MODULE_DECLARE_SIMPLE(eeprom_mmap_file);

/*
** Simulate EEPROM by mapping in a file
*/
int32 CFE_PSP_SetupEEPROM(uint32 EEPROMSize, cpuaddr *EEPROMAddress)
{
    int   FileDescriptor;
    int   ReturnStatus;
    void *DataBuffer;

    DataBuffer     = NULL;
    FileDescriptor = open(EEPROM_FILE, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);
    if (FileDescriptor < 0)
    {
        OS_printf("CFE_PSP: Cannot open EEPROM File: %s\n", EEPROM_FILE);
        perror("CFE_PSP: open");
        ReturnStatus = CFE_PSP_ERROR;
    }
    else if (ftruncate(FileDescriptor, EEPROMSize) < 0)
    {
        OS_printf("CFE_PSP: ftruncate(%s) error: %s\n", EEPROM_FILE, strerror(errno));
        ReturnStatus = CFE_PSP_ERROR;
    }
    else
    {
        DataBuffer = mmap(NULL, EEPROMSize, PROT_READ | PROT_WRITE, MAP_SHARED, FileDescriptor, 0);
        if (DataBuffer == (void *)(-1))
        {
            OS_printf("CFE_PSP: mmap to EEPROM File failed: %s\n", strerror(errno));
            ReturnStatus = CFE_PSP_ERROR;
        }
        else
        {
            ReturnStatus = CFE_PSP_SUCCESS;
        }
    }

    /* POSIX says that a mapped pointer counts as a file ref, so the FD
     * can be safely closed in all cases, success or failure */
    if (FileDescriptor >= 0)
    {
        close(FileDescriptor);
    }

    /*
    ** Return the address to the caller
    */
    if (ReturnStatus == CFE_PSP_SUCCESS)
    {
        *EEPROMAddress = (cpuaddr)DataBuffer;
    }
    else
    {
        *EEPROMAddress = 0;
    }

    return ReturnStatus;
}

/* For read/write - As this is mmap'ed we dereference the pointer directly.
 * Hopefully the caller didn't get it wrong.
 * No need to do anything special for 8/16/32 width access in this mode.
 */
int32 CFE_PSP_EepromWrite32(cpuaddr MemoryAddress, uint32 uint32Value)
{
    *((uint32 *)MemoryAddress) = uint32Value;
    return CFE_PSP_SUCCESS;
}

int32 CFE_PSP_EepromWrite16(cpuaddr MemoryAddress, uint16 uint16Value)
{
    *((uint16 *)MemoryAddress) = uint16Value;
    return CFE_PSP_SUCCESS;
}

int32 CFE_PSP_EepromWrite8(cpuaddr MemoryAddress, uint8 ByteValue)
{
    *((uint8 *)MemoryAddress) = ByteValue;
    return CFE_PSP_SUCCESS;
}

int32 CFE_PSP_EepromWriteEnable(uint32 Bank)
{
    return CFE_PSP_ERROR_NOT_IMPLEMENTED;
}

int32 CFE_PSP_EepromWriteDisable(uint32 Bank)
{
    return CFE_PSP_ERROR_NOT_IMPLEMENTED;
}

int32 CFE_PSP_EepromPowerUp(uint32 Bank)
{
    return CFE_PSP_SUCCESS;
}

int32 CFE_PSP_EepromPowerDown(uint32 Bank)
{
    return CFE_PSP_SUCCESS;
}

void eeprom_mmap_file_Init(uint32 PspModuleId)
{
    int32   Status;
    cpuaddr eeprom_address;
    uint32  eeprom_size;

    /* Inform the user that this module is in use */
    printf("CFE_PSP: Using MMAP simulated EEPROM implementation\n");

    /*
    ** Create the simulated EEPROM segment by mapping a memory segment to a file.
    ** Since the file will be saved, the "EEPROM" contents will be preserved.
    ** Set up 512Kbytes of EEPROM
    */
    eeprom_size = 0x80000;
    Status      = CFE_PSP_SetupEEPROM(eeprom_size, &eeprom_address);

    if (Status == 0)
    {
        /*
        ** Install the 2nd memory range as the mapped file ( EEPROM )
        */
        Status = CFE_PSP_MemRangeSet(1, CFE_PSP_MEM_EEPROM, eeprom_address, eeprom_size, CFE_PSP_MEM_SIZE_DWORD,
                                     CFE_PSP_MEM_ATTR_READWRITE);
        OS_printf("CFE_PSP: EEPROM Range (2) created: Start Address = %08lX, Size = %08X Status = %d\n",
                  (unsigned long)eeprom_address, (unsigned int)eeprom_size, (int)Status);
    }
    else
    {
        OS_printf("CFE_PSP: Cannot create EEPROM Range from Memory Mapped file.\n");
    }
}
