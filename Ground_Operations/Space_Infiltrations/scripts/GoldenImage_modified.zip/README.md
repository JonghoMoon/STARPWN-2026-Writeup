# Golden Image Package

This package contains the software image and supporting tools used for the space vehicle mission.

## Status files

This package includes **good-status.txt**, **warning-status.txt**, **error-status.txt**, and **catastrophic-status.txt**, which are used by **status-generator.py** to downlink status messages to the ground. When the golden image is uploaded to the satellite, these files are installed at **/opt/**.

## Build and deployment

The code in **image/** is the NASA Core Flight System (cFS) source tree. It is built on the ground station to produce the flight binary before being sent to the satellite. The resulting image is the spacecraft's **golden image**: it is loaded as the primary flight software and is also used as the recovery image should an unrecoverable fault occur on orbit.

## Encryption

The golden image is **encrypted on the ground station** before uplink. It is **decrypted on the satellite** after receipt using the key stored in **/opt/flag.txt** on the vehicle. Do not include the key in this package; it is installed separately on the spacecraft.

## Status generator

On the satellite, **status-generator.py** produces the status messages that are downlinked to the ground. It imports **nasa-cfs-api**, calls **connect_to_cfs_api()** to create a connection, then **connection.get_status()** to get a status code. The code is an integer 0–3: **0** = Functioning Normally (good-status.txt), **1** = Warning (warning-status.txt), **2** = Error (error-status.txt), **3** = Catastrophic Failure (catastrophic-status.txt). The contents of the corresponding file are downlinked. If **nasa-cfs-api** cannot be imported (e.g. on the ground), the script falls back to outputting only the contents of **good-status.txt**. The status files are read from **/opt/** on the spacecraft.

## Recovery scenarios

The golden image is automatically restored in the following unrecoverable fault scenarios:

- **EPS (Electrical Power System) faults**: If the power system detects a critical undervoltage, overcurrent, or bus fault, the vehicle will power-cycle the payload processor and boot from the golden image.
- **Power-On Reset**: Any full power-on or processor reset (e.g. after safe mode or watchdog) boots from the golden image to ensure a known-good software state.

In both cases, the satellite will come up running this image until a new image is uplinked and validated.
