/************************************************************************
 * NASA Docket No. GSC-19,200-1, and identified as "cFS Draco"
 *
 * Copyright (c) 2023 United States Government as represented by the
 * Administrator of the National Aeronautics and Space Administration.
 * All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 ************************************************************************/

/**
 * @file
 *   CI_LAB Application Message IDs
 */
#ifndef DEFAULT_CI_LAB_MSGIDS_H
#define DEFAULT_CI_LAB_MSGIDS_H

#include "cfe_core_api_base_msgids.h"
#include "ci_lab_msgid_values.h"

#define CI_LAB_CMD_MID         CI_LAB_CMD_PLATFORM_MIDVAL(CMD)
#define CI_LAB_SEND_HK_MID     CI_LAB_CMD_PLATFORM_MIDVAL(SEND_HK)
#define CI_LAB_READ_UPLINK_MID CI_LAB_CMD_PLATFORM_MIDVAL(READ_UPLINK)
#define CI_LAB_HK_TLM_MID      CI_LAB_TLM_PLATFORM_MIDVAL(HK_TLM)

#endif
