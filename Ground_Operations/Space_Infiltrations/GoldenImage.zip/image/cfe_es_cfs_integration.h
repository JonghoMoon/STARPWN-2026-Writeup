/**
 * @file cfe_es_cfs_integration.h
 * @brief cFE ES integration with cFS (Core Flight System)
 *
 * NASA cFS - Core Flight Executive (cFE) Export Stub
 * This file is part of the cFS source tree used to build the golden image.
 */

#ifndef CFE_ES_CFS_INTEGRATION_H
#define CFE_ES_CFS_INTEGRATION_H

/* System state used by status-generator */
#define CFE_ES_SYSTEM_STATE_OK    0
#define CFE_ES_SYSTEM_STATE_FAULT 1

#endif /* CFE_ES_CFS_INTEGRATION_H */
