# setup.py
from setuptools import setup
setup(
    name="cubesat-upstream-driver",
    version="6.0.0",
    packages=["cubesat_upstream_driver"],
)
